#include "myheader.h"

errorflag ef = 0;

void openfile(FILE ** fp, char * filename, char * mode){
	if((*fp=fopen(filename,mode)) == NULL){
		fprintf(stderr, "*** Opening file [%s] failed! ***\n", filename);
		ef = 4;
	}
}
int errorCheck(void) {
	if (ef){
		printf("pass stopped by ef [");
		switch(ef){
			case 1: 
				printf("1:duplicate symbol]\n");
				return 1;
			case 2: printf("2:invalid operation]\n");
				return 2;
			case 3: printf("3;undefined symbol]\n");
				return 3;
			default:
				printf("unknown error]\n");
				return 4;
		}
	}
	return 0;
}
int main(void){
	PASS1();
	if(errorCheck())
		return -1;
	length = LOCCTR - strtoul(startAddr, NULL, 16);	//save (LOCCTR - starting address) as program length
	PASS2();
	if(errorCheck())
		return -2;
	return;
}
