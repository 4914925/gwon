#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//extern void openfile(FILE ** fp, char * filename, char * mode);
typedef struct opTab {
	char mnemonic[7];	//changed from opcode to mnemonic
	char opcode[7];		//changed from objcode to opcode
} opTab;
typedef struct symTab {
	char symbol[10];
	int addr;
} symTab;
typedef struct record {
	char label[7], mnemonic[10], operand[10], commentLine[50];
} record;
typedef struct imline{
	char line[10], label[10], mnemonic[50], operand[20], loc[7], pc[7], objcode[7];	//changed from objectcode to objcode
} imline;	//changed from im_record to imline

typedef int errorflag;
extern errorflag ef;

extern void openfile(FILE ** fp, char * filename, char * mode);
extern opTab myOpTab[26];
extern symTab mySymTab[20];
extern record rec;
extern imline line;

extern char startAddr[7];
extern int LOCCTR, SymCount;
extern int length;
extern void PASS1(void);
extern void PASS2(void);

/*
1 : duplicate_symbol;
2 : invalid_operation_code;
3 : undefined_symbol;
4 : cannot open file;
*/
