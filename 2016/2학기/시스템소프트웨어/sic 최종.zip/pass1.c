#include"myheader.h"
void chk_label();
void chk_mnemonic();
void READ_LINE();


symTab mySymTab[20];

int length;
char startAddr[7];
int lineNumber = 0;
int LOCCTR = 0;
int PCCTR = 0;
int symCount = 0;
record rec;
FILE *input;
void PASS1(void)
{
	int i;
	FILE *inter;
	openfile(&input, "input.txt", "r");
	openfile(&inter, "inter.txt", "w");
	READ_LINE();
	if (strcmp(rec.mnemonic, "START") == 0)	//if OPCODE = 'START'
	{
		strcpy(startAddr, rec.operand);//save #[OPERAND] as starting address
		LOCCTR = strtoul(startAddr, NULL, 16);	//initialize LOCCTR to starting address	
		fprintf(inter, "%d\n%s\n%s\n%s\n%X\n\n", lineNumber, rec.label, rec.mnemonic, rec.operand, LOCCTR);	//write line to intermediate file
		//printf("%d\n%s\n%s\n%s\n%X\n\n", lineNumber, rec.label, rec.mnemonic, rec.operand, LOCCTR);	//write line to intermediate file
		READ_LINE();
	
		//printf("%d\n%s\n%s\n%s\n%X\n\n", lineNumber, rec.label, rec.mnemonic, rec.operand, LOCCTR);	//write line to intermediate file
	}
	else
	{
		strcpy(startAddr, "0");
		LOCCTR = 0;	//initialize LOCCTR to 0
	}
	PCCTR = LOCCTR;
	while (strcmp(rec.mnemonic, "END") != 0) {	//OPCODE < > 'END'
		if(strcmp(rec.label, "$") != 0){
			chk_label();	//search SYMTAB for LABEL
			chk_mnemonic();	//search OPTAB for OPCODE
		//fprintf(inter, "%s	%s	%s\n", label, mnemonic, operand);	//write line to intermediate file
		fprintf(inter, "%d\n%s\n%s\n%s\n%X\n%X\n", lineNumber, rec.label, rec.mnemonic, rec.operand, LOCCTR, PCCTR);
		LOCCTR = PCCTR;
		}
		else
		{
			fprintf(inter, "%d\n%s\n%s\n\n\n", lineNumber, rec.label, rec.commentLine);
		}
		READ_LINE();
	}
	fprintf(inter, "%d\n%s\n%s\n%s\n%X\n", lineNumber, rec.label, rec.mnemonic, rec.operand, LOCCTR);
	fclose(inter);
	fclose(input);
/*
	for(i=0;i<symCount;i++){
		printf("%s\t%d\n", mySymTab[i].symbol, mySymTab[i].addr);
	}
*/
}

void chk_label()
{
	int i;
	if(rec.label[0] != '\0'){
		for (i = 0; i < symCount; i++) {
			if (strcmp(rec.label, mySymTab[i].symbol) == 0)
			{
				ef = 1;
				return;
			}
		}
		strcpy(mySymTab[symCount].symbol, rec.label);
		mySymTab[symCount++].addr = LOCCTR;
	}
	
}


void chk_mnemonic() {
	int i = 0, found = 0, l = 0;
	for (i = 0; i < 26; i++)
	{
		if (strcmp(rec.mnemonic, myOpTab[i].mnemonic) == 0) //found
		{
			//add 3 to LOCCTR
			PCCTR += 3;
			found = 1;
			break;
		}
	}
	if (found==0)
	{
		if (strcmp(rec.mnemonic, "WORD") == 0)	//OPCODE = 'WORD'
			PCCTR += 3;	//add 3 to LOCCTR
		else if (strcmp(rec.mnemonic, "RESW") == 0)	//OPCODE = 'RESW'
			PCCTR += (3 * atoi(rec.operand));	//add 3*#[OPERAND] to LOCCTR
		else if (strcmp(rec.mnemonic, "RESB") == 0)	//OPCODE = 'RESB'
			PCCTR += atoi(rec.operand);	//add #[OPERAND] to LOCCTR
		else if (strcmp(rec.mnemonic, "BYTE") == 0)	//OPCODE = 'BYTE'
		{
			if (rec.operand[0] == 'C')	//if BYTE is CHARACTER
			{
				while (rec.operand[l] != '\0')
					l++;
				PCCTR = PCCTR + l - 3;	//CHARACTERi=
			}
			else if (rec.operand[0] == 'X')	//BYTE
			{
				while (rec.operand[l] != '\0')
					l++;
				PCCTR = PCCTR + (l - 3)/2;	
			}
			else {		//set error flag(invalid operation code)
				ef = 2;
			}
		}
	}
}

void READ_LINE() {
	char buffer[100];
	char * token;
	strcpy(rec.label, "\0");
	strcpy(rec.mnemonic, "\0");
	strcpy(rec.operand, "\0");
	fgets(buffer, 100, input);
	if(buffer[0] == ';'){
		return;
	}
	if (strchr(buffer, '.') != NULL){
		strcpy(rec.label, "$");
		strcpy(rec.commentLine, buffer);
		lineNumber += 5;
		return;
	}
	token = strtok(buffer, "\n");
	token = strtok(buffer, ";");
	if(token[0] != '\t'){
		token = strtok(token, "\t");
		//printf("%s|\t", token);
		strcpy(rec.label, token);
		token = strtok(NULL, "\t");
	}
	else
		token = strtok(token, "\t");
	//printf("%s|\t", token);
	strcpy(rec.mnemonic, token);
	token = strtok(NULL, "\t");
	if(token != NULL){
		//printf("%s|\n", token);
		strcpy(rec.operand, token);
	}
	lineNumber += 5;
}


