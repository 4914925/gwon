#include "myheader.h"


opTab myOpTab[26] = {
	{ "ADD","0x18" },{ "AND","0x40" },
	{ "COMP","0x28" },{ "DIV","0x24" },
	{ "J","0x3C" },{ "JEQ","0x30" },
	{ "JGT","0x34" },{ "JLT","0x38" },
	{ "JSUB","0x48" },{ "LDA","0x00" },
	{ "LDCH","0x50" },{ "LDL","0x08" },
	{ "LDX","0x04" },{ "MUL","0x20" },
	{ "OR","0x44" },{ "RD","0xD8" },
	{ "RSUB","0x4C" },{ "STA","0x0C" },
	{ "STCH","0x54" },{ "STL","0x14" },
	{ "STSW","0xE8" },{ "STX","0x10" },
	{ "SUB","0x1C" },{ "TD","0xE0" },
	{ "TIX","0x2C" },{ "WD","0xDC" }
};
imline line; // record structure
FILE * object; //output program
FILE * list;	//listing file
FILE *inter;
char filename[7];

int xcheck(){
    int i;
    for(i=0;i<strlen(line.operand);i++){
        if(line.operand[i] == ','){
            return 1;
        }
    }
    return 0;
}

void assemble(int *x, int *operval, int *i){	
	sprintf(line.objcode, "%02X%04X", (unsigned int)strtoul(myOpTab[*i].opcode, NULL, 16), (*x) * 32768 + (*operval));
}

int wtext(){
	int i, j;
	int optablen = sizeof(myOpTab) / sizeof(myOpTab[0]);
	int symtablen = sizeof(mySymTab) / sizeof(mySymTab[0]);
	int operval;
	int x;
	int maxTextLen = 30;
	int curTextLen = 0;
	int textlenloc;
	int addlen=0;
	int chkres = 0;
	char operand[10];
	char *tmp;
	//initialize first text record
	fprintf(object, "T^");
	for(i=strlen(line.loc);i<6;i++){
		fprintf(object, "0");
	}
	fprintf(object, "%s^", line.loc);
	textlenloc = ftell(object);
	fprintf(object, "00");
	
	while(strcmp(line.mnemonic,"END")!=0){	//while OPCODE != 'END' do
		addlen = 0;
		if(strcmp(line.label,"$") == 0){	//if this is not a comment line continue;
			fprintf(list, "%s\t%s\n", line.line, line.mnemonic);
			rdline();
			continue;
		}
		for(i=0;i<optablen;i++){	//search OPTAB for OPCODE
			if(strcmp(line.mnemonic,myOpTab[i].mnemonic)==0){	//if found then
				j = i;
				if(line.operand != NULL){	//if there is a symbol in OPERAND field then
					strcpy(operand, line.operand);	//check if using x register
					if((x = xcheck()) == 1){
						tmp = strtok(operand, ",");
						strcpy(operand, tmp);
					}
					operval = 0;
					for(i=0;i<symtablen;i++){	//search SYMTAB for OPERAND
						if(strcmp(operand,mySymTab[i].symbol)==0){	//if found then
							operval = mySymTab[i].addr;	//store symbol value as operand address
							break;
						}
					}
					if(i == symtablen){
						printf("No symbol founded! : %s", operand);
						ef = 3;
						return;
					}
				} else {
					operval = 0;	//store 0 as operand address
				}
			addlen = 3;
			assemble(&x, &operval, &j);	//assemble the object code instruction
			break;
			}
		}
        	if((strcmp(line.mnemonic,"BYTE")==0)||(strcmp(line.mnemonic,"WORD")==0)){	//else if OPCODE = 'BYTE' or 'WORD' then
			if(line.operand[0] == 'C'){
				char tmp[4];
				for(i=2;line.operand[i] != '\'';i++){
					tmp[i-2] = line.operand[i];
				}
				sprintf(line.objcode, "%02X%02X%02X", tmp[0], tmp[1], tmp[2]);
				addlen = i-2;
			}
			else if(line.operand[0] == 'X'){
				line.objcode[0] =  line.operand[2];
				line.objcode[1] =  line.operand[3];
				line.objcode[2] = '\0';
				addlen = 1;
			}
			else{
				sprintf(line.objcode, "%06X", atoi(line.operand));
				addlen = 3;
			}
			
		}
		if(strcmp(line.mnemonic,"RESW")==0||strcmp(line.mnemonic,"RESB")==0){
			while(strcmp(line.mnemonic,"RESW")==0||strcmp(line.mnemonic,"RESB")==0){
				strcpy(line.objcode, "");
				wlist();
				rdline();
            		}
			chkres = 1;
		}
		if(maxTextLen < curTextLen+addlen || chkres == 1){	//if object code will not fit into the current Text record then
			/* fseek, ftell*/
			fseek(object, textlenloc, SEEK_SET);
			fprintf(object, "%02X", curTextLen);
			fseek(object, 0, SEEK_END);

			fprintf(object, "\nT^");
			for(i=strlen(line.pc);i<6;i++){
				fprintf(object, "0");
			}
			fprintf(object, "%s^", line.loc);

			textlenloc = ftell(object);
			fprintf(object, "00");
			curTextLen = 0;
			chkres = 0;
		}
		fprintf(object, "^%s", line.objcode);
		curTextLen += addlen;
		wlist();
		rdline();
	}
	strcpy(line.objcode, "");
	strcpy(line.loc, "");

	fseek(object, textlenloc, SEEK_SET);
	fprintf(object, "%02X", curTextLen);
	fseek(object, 0, SEEK_END);
}

void wend(){
	fprintf(object, "\nE^%06X", (unsigned int)strtoul(startAddr,NULL,16));
}
void wheader(){
	fprintf(object, "H^%6s^%06X^%06X\n", filename, (unsigned int)strtoul(startAddr,NULL,16), length);
}
int initlist(){
	fprintf(list, "Line\tLoc\t\tSource Statement\t\tObject Code\n");
	fprintf(list, "------------------------------------------------------------------------\n\n");
}
	
int wlist(){
	fprintf(list, "%s\t%s\t0\t%s\t%s\t%s\t%s\n", line.line, line.loc, line.label, line.mnemonic, line.operand, line.objcode);
}

int rdline(){
	char *tmp;
	if(fgets(line.line, 10, inter) != NULL){
		fgets(line.label, 10, inter);
		fgets(line.mnemonic, 50, inter);
		fgets(line.operand, 10, inter);
		fgets(line.loc, 10, inter);
		fgets(line.pc, 10, inter);
	}
	if((tmp = strstr(line.line, "\n"))!= NULL) *tmp = '\0';
	if((tmp = strstr(line.label, "\n"))!= NULL) *tmp = '\0';
	if((tmp = strstr(line.mnemonic, "\n"))!= NULL) *tmp = '\0';
	if((tmp = strstr(line.operand, "\n"))!= NULL) *tmp = '\0';
	if((tmp = strstr(line.loc, "\n"))!= NULL) *tmp = '\0';
	if((tmp = strstr(line.pc, "\n"))!= NULL) *tmp = '\0';
}
void PASS2(void){
	openfile(&inter, "inter.txt", "r");
	openfile(&object, "object.txt", "w");
	openfile(&list, "list.txt", "w");
	
	rdline();
	initlist();
	
	strcpy(line.objcode, "");
	
	if(strcmp(line.mnemonic, "START") == 0){
		wlist();
		strcpy(filename, line.label);
		rdline();
	}
	//write Header record to object program
	wheader();
	//initialize first Text record
	//init_record();
	//write text record and write listing
	wtext(); // listing (    object     )
	//write end record and write listing
	wend();
	wlist();
	fclose(inter);
	fclose(object);
	fclose(list);
	//pass2 end
}
