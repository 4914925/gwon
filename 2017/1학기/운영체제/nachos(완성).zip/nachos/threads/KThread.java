package nachos.threads;

//Vector 클래스 사용을 위해 import함 -jmh-

import java.util.Vector;

import nachos.machine.*;

/**
 * A KThread is a thread that can be used to execute Nachos kernel code. Nachos
 * allows multiple threads to run concurrently.
 *
 * To create a new thread of execution, first declare a class that implements
 * the <tt>Runnable</tt> interface. That class then implements the <tt>run</tt>
 * method. An instance of the class can then be allocated, passed as an
 * argument when creating <tt>KThread</tt>, and forked. For example, a thread
 * that computes pi could be written as follows:
 *
 * <p><blockquote><pre>
 * class PiRun implements Runnable {
 *     public void run() {
 *         // compute pi
 *         ...
 *     }
 * }
 * </pre></blockquote>
 * <p>The following code would then create a thread and start it running:
 *
 * <p><blockquote><pre>
 * PiRun p = new PiRun();
 * new KThread(p).fork();
 * </pre></blockquote>
 */
public class KThread {
    /**
     * Get the current thread.
     *
     * @return	the current thread.
     */
    public static KThread currentThread() {
	Lib.assertTrue(currentThread != null);
	return currentThread;
    }
    
    /**
     * Allocate a new <tt>KThread</tt>. If this is the first <tt>KThread</tt>,
     * create an idle thread as well.
     */
    public KThread() {
	if (currentThread != null) {	//현재 스레드가 최초로 만들어진 스레드가 아닌경우 -jmh-
	    tcb = new TCB();	//새로운 tcb를 생성한다. -jmh-
	    
	    //스래드 리스트 저장을 위한 자료구조 초기화 -jmh-
	    joined_thread = new Vector();
	}	    
	else {
	    readyQueue = ThreadedKernel.scheduler.newThreadQueue(false);
	    readyQueue.acquire(this);	    

	    currentThread = this;
	    tcb = TCB.currentTCB();
	    name = "main";
	    restoreState();

	    createIdleThread();
	}
    }

    /**
     * Allocate a new KThread.
     *
     * @param	target	the object whose <tt>run</tt> method is called.
     */
    public KThread(Runnable target) {
	this();	//매개변수가 없는 KThread생성자를 실행한다. -jmh-
	this.target = target;	//입력된 값을 target로 설정한다. -jmh-
    }

    /**
     * Set the target of this thread.
     *
     * @param	target	the object whose <tt>run</tt> method is called.
     * @return	this thread.
     */
    public KThread setTarget(Runnable target) {
	Lib.assertTrue(status == statusNew);
	
	this.target = target;
	return this;
    }

    /**
     * Set the name of this thread. This name is used for debugging purposes
     * only.
     *
     * @param	name	the name to give to this thread.
     * @return	this thread.
     */
    public KThread setName(String name) {
	this.name = name;
	return this;
    }

    /**
     * Get the name of this thread. This name is used for debugging purposes
     * only.
     *
     * @return	the name given to this thread.
     */     
    public String getName() {
	return name;
    }

    /**
     * Get the full name of this thread. This includes its name along with its
     * numerical ID. This name is used for debugging purposes only.
     *
     * @return	the full name given to this thread.
     */
    public String toString() {
	return (name + " (#" + id + ")");
    }

    /**
     * Deterministically and consistently compare this thread to another
     * thread.
     */
    public int compareTo(Object o) {
	KThread thread = (KThread) o;

	if (id < thread.id)
	    return -1;
	else if (id > thread.id)
	    return 1;
	else
	    return 0;
    }

    /**
     * Causes this thread to begin execution. The result is that two threads
     * are running concurrently: the current thread (which returns from the
     * call to the <tt>fork</tt> method) and the other thread (which executes
     * its target's <tt>run</tt> method).
     */
    public void fork() {
	Lib.assertTrue(status == statusNew);
	Lib.assertTrue(target != null);
	
	Lib.debug(dbgThread,
		  "Forking thread: " + toString() + " Runnable: " + target);

	boolean intStatus = Machine.interrupt().disable();

	tcb.start(new Runnable() {	//tcb.start에의해 Thread API를 이용해서 실제 thread를 실행시킨다. -jmh-
		public void run() {
		    runThread();
		}
	    });

	ready();
	
	Machine.interrupt().restore(intStatus);
    }

    private void runThread() {
	begin();
	target.run();
	finish();
    }

    private void begin() {
	Lib.debug(dbgThread, "Beginning thread: " + toString());
	
	Lib.assertTrue(this == currentThread);

	restoreState();	//현재 스레드를 running상태로 만든다. -jmh-

	Machine.interrupt().enable();
    }

    /**
     * Finish the current thread and schedule it to be destroyed when it is
     * safe to do so. This method is automatically called when a thread's
     * <tt>run</tt> method returns, but it may also be called directly.
     *
     * The current thread cannot be immediately destroyed because its stack and
     * other execution state are still in use. Instead, this thread will be
     * destroyed automatically by the next thread to run, when it is safe to
     * delete this thread.
     */
    public static void finish() {
	Lib.debug(dbgThread, "Finishing thread: " + currentThread.toString());
	
	Machine.interrupt().disable();

	Machine.autoGrader().finishingCurrentThread();

	Lib.assertTrue(toBeDestroyed == null);
	toBeDestroyed = currentThread;


	currentThread.status = statusFinished;
	
	sleep();
    }

    /**
     * Relinquish the CPU if any other thread is ready to run. If so, put the
     * current thread on the ready queue, so that it will eventually be
     * rescheuled.
     *
     * <p>
     * Returns immediately if no other thread is ready to run. Otherwise
     * returns when the current thread is chosen to run again by
     * <tt>readyQueue.nextThread()</tt>.
     *
     * <p>
     * Interrupts are disabled, so that the current thread can atomically add
     * itself to the ready queue and switch to the next thread. On return,
     * restores interrupts to the previous state, in case <tt>yield()</tt> was
     * called with interrupts disabled.
     */
    public static void yield() {
	Lib.debug(dbgThread, "Yielding thread: " + currentThread.toString());
	
	Lib.assertTrue(currentThread.status == statusRunning);
	
	boolean intStatus = Machine.interrupt().disable();

	currentThread.ready();	//현재 스레드를 ready상태로 만든다. -jmh-

	runNextThread();	//readyQueue에 있는 다음 스레드를 Running한다. -jmh-
	
	Machine.interrupt().restore(intStatus);
    }

    /**
     * Relinquish the CPU, because the current thread has either finished or it
     * is blocked. This thread must be the current thread.
     *
     * <p>
     * If the current thread is blocked (on a synchronization primitive, i.e.
     * a <tt>Semaphore</tt>, <tt>Lock</tt>, or <tt>Condition</tt>), eventually
     * some thread will wake this thread up, putting it back on the ready queue
     * so that it can be rescheduled. Otherwise, <tt>finish()</tt> should have
     * scheduled this thread to be destroyed by the next thread to run.
     */
    public static void sleep() {
	Lib.debug(dbgThread, "Sleeping thread: " + currentThread.toString());
	
	Lib.assertTrue(Machine.interrupt().disabled());

	if (currentThread.status != statusFinished)	//현재 스레드의 상태가 종료된 상태가 아니면 -jmh-
	    currentThread.status = statusBlocked;	//스레드의 상태를 강제로 Blocked된 상태로 만들어준다. -jmh-

	runNextThread();	//readyQueue에 있는 다음 스레드를 Running한다. -jmh-
    }

    /**
     * Moves this thread to the ready state and adds this to the scheduler's
     * ready queue.
     */
    public void ready() {
	Lib.debug(dbgThread, "Ready thread: " + toString());
	
	Lib.assertTrue(Machine.interrupt().disabled());
	Lib.assertTrue(status != statusReady);
	
	status = statusReady;	//현재 스레드의 상태를 ready상태로 전환한다. -jmh-
	if (this != idleThread)	//현재 스레드가 최초의 스레드가 아닌경우 -jmh-
	    readyQueue.waitForAccess(this);	//현재스레드를 readyQueue에 집어 넣는다. -jmh-
	
	Machine.autoGrader().readyThread(this);	//스레드를 ready할수 있는 형태로 만든다. -jmh-
    }

    /**
     * Waits for this thread to finish. If this thread is already finished,
     * return immediately. This method must only be called once; the second
     * call is not guaranteed to return. This thread must not be the current
     * thread.
     */
    //join은 기다리고자 하는 스레드가 작업이 선행되어야 하는 스레드의 join을 호출한다.	-jmh-
    //ex)C스레드가 A스레드에 join이 필요하면 C스레드가 A스레드의 join()을 호출한다. 즉 여기서 currentThread는 C스레드이지만 join()은 A스레드의 메소드이다. -jmh-
    //그러므로 안에 있는 joined_thread는 A스레드의 변수이다.	-jmh-
    
    public void join() {	
	Lib.debug(dbgThread, "Joining to thread: " + toString());

	Lib.assertTrue(this != currentThread);
	
	
	if(this.status == statusFinished) return;	//ex) C스레드가 끝난 상태이면 바로 리턴한다.	-jmh-
	boolean intStatus = Machine.interrupt().disable();	//스케줄링 작업도중에 인터럽트를 하지못하도록 막는 작업	-jmh-
	joined_thread.addElement((KThread)currentThread);	//현재 쓰레드를 joined_thread의 맨뒤에 이름을 적는다. ex) C스레드를 A의 joined_thread맨뒤에 이름을 적는다.	-jmh-
	currentThread.sleep();	//joined_thread에 이름을 적어놨으니 슬립상태로 들어간다. ex)C스레드는 슬립상태로 들어간다.	-jmh-
	Machine.interrupt().restore(intStatus);	//인터럽트를 못하게 한 상태를 저장	-jmh-

    }

    /**
     * Create the idle thread. Whenever there are no threads ready to be run,
     * and <tt>runNextThread()</tt> is called, it will run the idle thread. The
     * idle thread must never block, and it will only be allowed to run when
     * all other threads are blocked.
     *
     * <p>
     * Note that <tt>ready()</tt> never adds the idle thread to the ready set.
     */
    private static void createIdleThread() {
	Lib.assertTrue(idleThread == null);
	
	idleThread = new KThread(new Runnable() {
	    public void run() { while (true) yield(); }
	});
	idleThread.setName("idle");

	Machine.autoGrader().setIdleThread(idleThread);
	
	idleThread.fork();	//최초의 스레드를 fork시킨다. 최초의 스레드를 fork 시키면 readyQueue에 들어가지 않고 반환됨 -jmh-
    }
    
    /**
     * Determine the next thread to run, then dispatch the CPU to the thread
     * using <tt>run()</tt>.
     */
    private static void runNextThread() {	//readyQueue에 있는 스레드를 실행 시키기 위한 메소드 -jmh-
	KThread nextThread = readyQueue.nextThread();	//readyQueue에 있는 스레드를 가져온다. -jmh-
	if (nextThread == null)	//가져온 스레드가 없으면, 즉 readyQueue가 비어있으면 -jmh-
	    nextThread = idleThread;	//다음 스레드를 없는 상태로 바꾼다. -jmh-

	nextThread.run();	//readyQueue에 스레드가 있으면 그 스레드를 실행하고 없으면 idle스레드를 실행한다. -jmh-
    }

    /**
     * Dispatch the CPU to this thread. Save the state of the current thread,
     * switch to the new thread by calling <tt>TCB.contextSwitch()</tt>, and
     * load the state of the new thread. The new thread becomes the current
     * thread.
     *
     * <p>
     * If the new thread and the old thread are the same, this method must
     * still call <tt>saveState()</tt>, <tt>contextSwitch()</tt>, and
     * <tt>restoreState()</tt>.
     *
     * <p>
     * The state of the previously running thread must already have been
     * changed from running to blocked or ready (depending on whether the
     * thread is sleeping or yielding).
     *
     * @param	finishing	<tt>true</tt> if the current thread is
     *				finished, and should be destroyed by the new
     *				thread.
     */
    private void run() {
	Lib.assertTrue(Machine.interrupt().disabled());
	Machine.yield();	//현재 실행중인 스레드를 중지 시키고 다른 스레드를 가져온다. -jmh-

	currentThread.saveState();	//현재 스레드의 상태를 체크한다. (의미없는 작업임) -jmh-

	Lib.debug(dbgThread, "Switching from: " + currentThread.toString()
		  + " to: " + toString());

	currentThread = this;	//가져온 스레드를 현제 스레드로 바꾼다. -jmh-

	tcb.contextSwitch(); //tcb를 contextSwitch한다. -jmh-

	currentThread.restoreState();	//가져온 스레드를 running상태로 만들어준다 -jmh-
    }

    /**
     * Prepare this thread to be run. Set <tt>status</tt> to
     * <tt>statusRunning</tt> and check <tt>toBeDestroyed</tt>.
     */
    protected void restoreState() {
	Lib.debug(dbgThread, "Running thread: " + currentThread.toString());
	Lib.assertTrue(Machine.interrupt().disabled());
	Lib.assertTrue(this == currentThread);
	Lib.assertTrue(tcb == TCB.currentTCB());

	Machine.autoGrader().runningThread(this);	//현재 스래드를 running할수 있는 상태로 바꾼다. -jmh-
	
	status = statusRunning;	//현재 스래드의 상태를 Running로 바꾼다. -jmh-
	
	//종료될 스레드를 마무리 처리하는 부분 -jmh-
	if (toBeDestroyed != null) {
		while(!toBeDestroyed.joined_thread.isEmpty())	//join을 당한 스레드가 종료시 join을 요청한 스레드가 있으면 ex)A가 종료시 joined_thread에 C가 적혀있으면 -jmh-
		{
			KThread TempThread;	//KThread형식의 임시 스레드 선언
			TempThread = (KThread)toBeDestroyed.joined_thread.get(0);	//joined_thread에 적힌 이름중 첫번째 이름을 KThread형식으로 가져온다. ex)joined_thread에서 C를 가져온다. -jmh-
			toBeDestroyed.joined_thread.remove(0);	//joined_thread에서 첫번째 이름을 지운다. ex)joined_thread에서 C의 이름을 지운다. -jmh-
			TempThread.ready();	//join을 한 스레드를 ready상태로 만든다. ex)C스레드를 ready상태로 만든다. -jmh-
		}
		//toBeDestroyed는 이전의 스레드 즉 context_switch당한 스레드이다. -jmh-
	    toBeDestroyed.tcb.destroy();	//종료될 스레드의 tcb를 파괴한다. -jmh-
	    toBeDestroyed.tcb = null;	//종료될 스레드의 tcb를 null로 초기화 한다. 즉 종료를 해야되는 스레드의 tcb가 없는 상태로 만듬-jmh-
	    toBeDestroyed = null;	//종료될 스레드를 null로 초기화 한다. 즉 종료를 해야되는 스레드가 없는 상태로 만듬-jmh-
	}
    }

    /**
     * Prepare this thread to give up the processor. Kernel threads do not
     * need to do anything here.
     */
    protected void saveState() {
	Lib.assertTrue(Machine.interrupt().disabled());	//현재 스레드가 실행중이면 false를 반환하고 종료榮摸 true를 반환한다. -jmh-
	Lib.assertTrue(this == currentThread);
    }

    private static class PingTest implements Runnable {
	PingTest(int which) {
	    this.which = which;
	}
	
	public void run() {
	    for (int i=0; i<10; i++) {
		System.out.println("*** thread " + which + " looped "
				   + i + " times");
		currentThread.yield();	//현재 스레드를 종료 시키고 readyQueue에 있는 다음스레드를 실행시킨다. -jmh-
	    }
	}

	private int which;
    }

    /**
     * Tests whether this module is working.
     */
    public static void selfTest() {
	Lib.debug(dbgThread, "Enter KThread.selfTest");
	/*
	KThread testThread1, testThread2, testThread3;	//테스트용 스레드 3개를 KThread형식으로 선언 -jmh-
	testThread1 = new KThread(new PingTest(1));	//스레드의 번호를 1번으로 해서 객체를 생성 -jmh-
	testThread2 = new KThread(new PingTest(2));	//스레드의 번호를 2번으로 해서 객체를 생성 -jmh-
	testThread3 = new KThread(new PingTest(3));	//스레드의 번호를 3번으로 해서 객체를 생성 -jmh-
	testThread1.fork();	//스레드 1을 fork시킨다. -jmh-
	testThread2.fork();	//스레드 2를 fork시킨다. -jmh-
	testThread3.fork();	//스레드 3을 fork시킨다. -jmh-
	testThread2.join();	//현재 스레드를(아직 번호가 없음) 2번스레드에 join한다. 즉 2번스레드가 끝나면 현재스레드를 수행하게 하는 작업 -jmh-
	*/
	KThread test1;
	ThreadQueue a;
	test1 = new KThread(new PingTest(1));
	test1.setName("forked thread").fork();
	a = test1.readyQueue;
	//new KThread(new PingTest(2)).setName("forked thread").fork();
	new PingTest(0).run();	//현재 스레드의 번호를 0으로 하고 실행을 시작한다. -jmh-
    }

    private static final char dbgThread = 't';

    /**
     * Additional state used by schedulers.
     *
     * @see	nachos.threads.PriorityScheduler.ThreadState
     */
    public Object schedulingState = null;

    private static final int statusNew = 0;
    private static final int statusReady = 1;
    private static final int statusRunning = 2;
    private static final int statusBlocked = 3;
    private static final int statusFinished = 4;

    /**
     * The status of this thread. A thread can either be new (not yet forked),
     * ready (on the ready queue but not running), running, or blocked (not
     * on the ready queue and not running).
     */
    private int status = statusNew;	//KThread생성시 상태를 new상태로 시작한다. -jmh-
    private String name = "(unnamed thread)";
    private Runnable target;
    private TCB tcb;

    /**
     * Unique identifer for this thread. Used to deterministically compare
     * threads.
     */
    private int id = numCreated++;
    /** Number of times the KThread constructor was called. */
    private static int numCreated = 0;

    private static ThreadQueue readyQueue = null;
    private static KThread currentThread = null;
    private static KThread toBeDestroyed = null;
    private static KThread idleThread = null;
    
    private Vector joined_thread = null;	//조인을 요청한 스래드가 어떤 것인지 저장할 자료구조 -jmh-
}

