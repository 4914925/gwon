request.
python 3 or up

edit from 'packet sniffer in python for Linux'
https://www.binarytides.com/python-packet-sniffer-code-linux/

use values from py.sniffer
https://github.com/meetrp/py.sniffer


how to use

from command

1. command [sudo python3 lms_sniff.py]

2. catch kyonggi lms login packet from local or others